import string, random
import mysql.connector
from airport import Airport
from goal import Goal
from database import Database
import config

class Game:

    def __init__(self, id, loc, consumption, player=None):
        self.status = {}
        self.location = []
        self.goals = []

        if id==0:
            # new game
            # Create new game id
            letters = string.ascii_lowercase + string.ascii_uppercase + string.digits

            self.status = {
                "id" : ''.join(random.choice(letters) for i in range(20)),
                "name" : player,
                "co2" : {
                    "consumed" : config.co2_initial,
                    "budget" : config.co2_budget
                },
                "previous_location" : ""
            }

            #self.id = ''.join(random.choice(letters) for i in range(20))
            #self.footprint = config.initial_footprint
            self.location.append(Airport(loc, True))
            #self.player = player
            # Insert new game into DB
            try:
                sql = "INSERT INTO Game VALUES ('" + self.status["id"] + "', " + str(self.status["co2"]["consumed"])
                sql += ", " + str(self.status["co2"]["budget"]) + ", '" + loc + "', '" + self.status["name"] + "')"
                # print(sql)
                conn = Database.get_connection()
                cur = conn.cursor()
                cur.execute(sql)
                conn.commit()
                cur.close()
                Database.put_connection(conn)
                print("[+] Game started successfully")
            except Exception as e:
                print("[!] An error occurred while executing the SQL statement:", e)
        else:
            print("[*] Starting Flight")
            #update consumption and budget
            try:
                sql2 = "UPDATE Game SET co2_consumed = co2_consumed + " + consumption + ", co2_budget = co2_budget - " + consumption + " WHERE id='" + id + "'"
                # print(sql2)
                conn = Database.get_connection()
                cur2 = conn.cursor()
                cur2.execute(sql2)
                conn.commit()
                cur.close()
                Database.put_connection(conn)
                print("[+ Step 1] Co2 updated successfully")
            except Exception as e:
                print("[!] An error occurred while executing the SQL statement:", e)

            # find game from DB
            sql = "SELECT id, co2_consumed, co2_budget, location, screen_name FROM Game WHERE id='" + id + "'"
            # print(sql)
            conn = Database.get_connection()
            cur = conn.cursor()
            try:
                cur.execute(sql)
                res = cur.fetchall()
                conn.commit()
                cur.close()
                Database.put_connection(conn)
                print("[+ Step 2] Data selected successfully!")
                if len(res) == 1:
                    # airport found
                    self.status = {
                        "id": res[0][0],
                        "name": res[0][4],
                        "co2": {
                            "consumed": res[0][1],
                            "budget": res[0][2]
                        },
                        "previous_location" : res[0][3]
                    }
                    # old location in DB currently not used
                    apt = Airport(loc, True)
                    self.location.append(apt)
                    self.set_location(apt)
                    print("[+ Step 3] Game found")
                else:
                    print("************** PELIÄ EI LÖYDY! ***************")
            except Exception as e:
                print("An error occurred while executing the SQL statement:", e)
                
        # read game's goals
        self.fetch_goal_info()


    def set_location(self, location):
        sql = "UPDATE Game SET location='" + location.ident + "' WHERE id='" + self.status["id"] + "'"
        # print(sql)
        conn = Database.get_connection()
        cur = conn.cursor()
        if cur.execute(sql):
            conn.commit()
            cur.close()
            conn.close()
            Database.close_all_connections(conn)
            print("[+] Location set successfully!")
        else:
            print("[!] Error updating location:")


    def fetch_goal_info(self):
        try:
            sql = "SELECT * FROM (SELECT Goal.id, Goal.name, Goal.description, Goal.icon, goal_reached.game_id, "
            sql += "Goal.target, Goal.target_minvalue, Goal.target_maxvalue, Goal.target_text "
            sql += "FROM Goal INNER JOIN goal_reached ON Goal.id = goal_reached.goal_id "
            sql += "WHERE goal_reached.game_id = '" + self.status["id"] + "' "
            sql += "UNION SELECT Goal.id, Goal.name, Goal.description, Goal.icon, NULL, "
            sql += "Goal.target, Goal.target_minvalue, Goal.target_maxvalue, Goal.target_text "
            sql += "FROM Goal WHERE Goal.id NOT IN ("
            sql += "SELECT Goal.id FROM Goal INNER JOIN goal_reached ON Goal.id = goal_reached.goal_id "
            sql += "WHERE goal_reached.game_id = '" + self.status["id"] + "')) AS t ORDER BY t.id;"

            # print(sql)
            conn = Database.get_connection()
            cur = conn.cursor()
            cur.execute(sql)
            res = cur.fetchall()
            for a in res:
                if a[4]==self.status["id"]:
                    is_reached = True
                else:
                    is_reached = False
                goal = Goal(a[0], a[1], a[2], a[3], is_reached, a[5], a[6], a[7], a[8])
                self.goals.append(goal)
            conn.commit()
            cur.close()
            Database.put_connection(conn)
            print("[+] Goal info fetched successfully!")
            return
        except Exception as e:
            print("[!] An error occurred while executing the SQL statement:", e)
