import json
from flask import Flask, render_template, redirect, request, url_for, current_app
from flask_cors import CORS
from database import Database
from game import Game
import logging

app = Flask(__name__)

# Define API endpoints
@app.route('/')
def index():
    return render_template('index.html')

def fly(id, dest, consumption=0, player=None):
    if id==0:
        game = Game(0, dest, consumption, player)
    else:
        game = Game(id, dest, consumption)
    game.location[0].fetchWeather(game)
    nearby = game.location[0].find_nearby_airports()
    for a in nearby:
        game.location.append(a)
    json_data = json.dumps(game, default=lambda o: o.__dict__, indent=4)
    return json_data

# http://127.0.0.1:8000/flyto?game=fEC7n0loeL95awIxgY7M&dest=EFHK&consumption=123
@app.route('/flyto')
def flyto():
    args = request.args
    id = args.get("game")
    dest = args.get("dest")
    consumption = args.get("consumption")
    json_data = fly(id, dest, consumption)
    return json_data
    
# http://127.0.0.1:8000/newgame?player=Emil&loc=LAX
@app.route('/newgame')
def newgame():
    args = request.args
    current_app.logger.info(args)
    player = args.get("player")
    dest = args.get("loc")
    print(f"player: {player}, dest: {dest}")
    json_data = fly(0, dest, 0, player)
    return json_data

if __name__ == '__main__':
    app.run(debug=True, use_reloader=True, port=8000)