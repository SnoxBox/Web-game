import mariadb
import sys
import configparser
import mysql.connector
import mysql.connector.pooling

class Database:
    __pool = None

    @staticmethod
    def init_pool():
        if Database.__pool is None:
            try:
                config = configparser.ConfigParser()
                config.read('config.ini')
                db_config = config['database']
                pool_config = {
                    'pool_name': db_config.get('pool_name', 'my_pool'),
                    'pool_size': db_config.getint('pool_size', 32),
                    'connection_timeout': db_config.getint('connection_timeout', 60),
                    'user': db_config['user'],
                    'password': db_config['password'],
                    'host': db_config['host'],
                    'port': db_config.getint('port', 3306),
                    'database': db_config['database']
                }
                Database.__pool = mysql.connector.pooling.MySQLConnectionPool(**pool_config)
            except mariadb.Error as e:
                print(f"Error connecting to MariaDB Platform: {e}")
                sys.exit(1)

    @staticmethod
    def get_connection():
        Database.init_pool()
        return Database.__pool.get_connection()

    @staticmethod
    def put_connection(conn):
        conn.close()

    @staticmethod
    def close_all_connections():
        if Database.__pool is not None:
            Database.__pool.close()
