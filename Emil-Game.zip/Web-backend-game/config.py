default_starting_point = "KLAX"
default_name = "Emil"

max_distance = 500
max_lat_dist = max_distance/50
max_lon_dist = max_distance/50

co2_initial = 0
co2_budget = 1000
co2_per_flight = 50
co2_per_km = 1

