import requests
import config
import os
from database import Database

class Weather:

    def __init__(self, location, game):
        apikey = 'APIKEY'

        request = "https://api.openweathermap.org/data/2.5/weather?lat=" + \
                 str(location.latitude) + "&lon=" + str(location.longitude) + "&appid=" + apikey
        response = requests.get(request).json()
        self.main = response["weather"][0]["main"]
        self.description = response["weather"][0]["description"]
        self.icon = "https://openweathermap.org/img/wn/" + response["weather"][0]["icon"] + ".png"
        self.temp = self.kelvin_to_celsius(response["main"]["temp"])
        self.humidity = response["main"]["humidity"]
        self.wind = {
            "speed": response["wind"]["speed"],
            "deg": response["wind"]["deg"]
        }

        self.meets_goals = []
        self.check_weather_goals(game)

    def kelvin_to_celsius(self, kelvin):
        return int (kelvin - 273.15)

    def check_weather_goals(self, game):
        for goal in game.goals:
            if goal.target=="TEMP":
                # temperature rule
                if self.temp>=goal.target_minvalue and self.temp<=goal.target_maxvalue:
                    self.meets_goals.append(goal.goalid)
            elif goal.target=="WEATHER":
                # weather type rule
                if self.main==goal.target_text:
                    self.meets_goals.append(goal.goalid)
            elif goal.target=="WIND":
                # wind rule
                if self.wind["speed"]>=goal.target_minvalue and self.wind["speed"]<=goal.target_maxvalue:
                    self.meets_goals.append(goal.goalid)

        for goal in game.goals:
            if goal.reached==False and goal.goalid in self.meets_goals:
                # new goal
                sql = "INSERT INTO goal_reached VALUES ('" + game.status["id"] + "', '" + str(goal.goalid)  + "')"
                print(sql)
                conn = Database.get_connection()
                cur = conn.cursor()
                cur.execute(sql)
                conn.commit()
                cur.close()
                Database.put_connection(conn)
                goal.reached = True
                print("[+] Reached goal recorded successfully!")
        return
