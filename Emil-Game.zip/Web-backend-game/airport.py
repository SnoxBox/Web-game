import random
import config
from database import Database
from weather import Weather
from geopy import distance
from typing import List

class Airport:
    def __init__(self, ident: str, active: bool = False, data: dict = None):
        self.ident = ident
        self.active = active

        if data is None:
            sql = f"SELECT ident, name, latitude_deg, longitude_deg FROM Airport WHERE ident='{ident}'"
            conn = Database.get_connection()
            cur = conn.cursor()
            cur.execute(sql)
            res = cur.fetchone()
            if res:
                self.ident, self.name, self.latitude, self.longitude = res
                print("[+] Airport found successfully")
        else:
            self.name = data['name']
            self.latitude = float(data['latitude'])
            self.longitude = float(data['longitude'])

    def find_nearby_airports(self) -> List:
        try:
            lista = []
            sql = f"SELECT ident, name, latitude_deg, longitude_deg FROM Airport WHERE latitude_deg BETWEEN {self.latitude - config.max_lat_dist} AND {self.latitude + config.max_lat_dist} AND longitude_deg BETWEEN {self.longitude - config.max_lon_dist} AND {self.longitude + config.max_lon_dist}"
            conn = Database.get_connection()
            cur = conn.cursor()
            cur.execute(sql)
            res = cur.fetchall()
            for r in res:
                if r[0] != self.ident:
                    data = {'name': r[1], 'latitude': r[2], 'longitude': r[3]}
                    nearby_apt = Airport(r[0], False, data)
                    nearby_apt.distance = self.distanceTo(nearby_apt)
                    if nearby_apt.distance <= config.max_distance:
                        lista.append(nearby_apt)
                        nearby_apt.co2_consumption = self.co2_consumption(nearby_apt.distance)
            print("[+] Nearby airports found!")
            return lista
        except Exception as e:
            conn.rollback()
            print("[!] An error occurred while executing the SQL statement:", e)

    def fetchWeather(self, game):
        self.weather = Weather(self, game)

    def distanceTo(self, target) -> int:
        coords_1 = (self.latitude, self.longitude)
        coords_2 = (target.latitude, target.longitude)
        dist = distance.distance(coords_1, coords_2).km
        return int(dist)

    def co2_consumption(self, km: int) -> float:
        consumption = config.co2_per_flight + km * config.co2_per_km
        return consumption