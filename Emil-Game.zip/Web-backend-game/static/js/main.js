// glob variables
const apiURL = 'http://127.0.0.1:8000/';
const startingLocation = 'KLAX';
const globalGoals = [];

// icons
const blueIcon = L.divIcon({className: 'blueIcon'});
const greenIcon = L.divIcon({className: 'greenIcon'});

// initialize the map
// [37.8, -96], 4
var mymap = L.map('map').setView([37.8, -96], 4);

// add the tile layer (using OpenStreetMap)
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
  maxZoom: 18,
}).addTo(mymap);

// get data from api
async function getData(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error('Invalid server');
  const data = await response.json();
  return data
}

// check if goals are reached
function checkGoals(meets_goals) {
  if (meets_goals.length > 0) {
    for (let goal of meets_goals) {
      if (!globalGoals.includes(goal)) {
        alert("A goal has been reached!")
      }
    }
  }
}

// check if game is over
function checkGameOver(budget) {
  if (budget <= 0) {
    alert("GAME OVER!!!!");
    return false;
  }
  return true;
}

// update goals
function updateGoals(goals) {
  const table = document.getElementById('goals');
  table.innerHTML = '';
  const tr = document.createElement('tr');
  const baseTemp = document.createElement('th');
  const baseWeather = document.createElement('th');
  const baseStat = document.createElement('th');

  baseTemp.innerText = "Temperature"
  baseWeather.innerText = "Weather"
  baseStat.innerText = "Status"

  tr.append(baseTemp);
  tr.append(baseWeather);
  tr.append(baseStat);
  table.append(tr);

  for (let goal of goals) {
    const tempTd = document.createElement('td');
    tempTd.setAttribute("id", "temp-table");
    tempTd.innerHTML = goal.description;

    const imgTd = document.createElement('td');
    
    const imgTd_img = document.createElement('img');
    imgTd_img.classList.add("weather-icon");
    imgTd_img.src = goal.icon;
    imgTd_img.alt = `Goal name: ${goal.name}`;
    imgTd.append(imgTd_img);

    const iconTd = document.createElement('td');
    if (goal.reached) {
      iconTd.classList.add("foundIcon");
      iconTd.classList.add("ri-check-double-line");
      if (!globalGoals.includes(goal.goalid)) {
        globalGoals.push(goal.goalid);
      }
    } else {
      iconTd.classList.add("notFoundIcon");
      iconTd.classList.add("ri-close-line");
    }

    const tr = document.createElement('tr');

    tr.append(tempTd);
    tr.append(imgTd);
    tr.append(iconTd);

    table.append(tr);
  }
}

// update game
function updateGame(status) {

  // update the game status
  document.getElementById("Text").innerText = `Player: ${status.name}`;
  document.getElementById("consumed-table").innerHTML = `${status.co2.consumed} kg`;
  console.log(status.co2.consumed);
  document.getElementById("budget-table").innerHTML = `${status.co2.budget} kg`;
}

// show weather at airport
function showWeather(airport) {
  document.getElementById('airport-table').innerHTML = airport.name;
  document.getElementById('wind-table').innerHTML = `${airport.weather.wind.speed}m/s`;
  document.getElementById('temp-table').innerHTML = `${airport.weather.temp}℃`;
  document.getElementById('weather-table').src = airport.weather.icon;
}

// set up the game
async function gameSetup(url) {
  try {
    const gameData = await getData(url);
    console.log(gameData);

    // update game
    updateGame(gameData.status);

    // check for game over
    if (!checkGameOver(gameData.status.co2.budget)) {
      return;
    }

    for (let airport of gameData.location) {
      const marker = L.marker([airport.latitude, airport.longitude]).addTo(mymap);
      if (airport.active) {
        showWeather(airport);
        checkGoals(airport.weather.meets_goals);
        marker.bindPopup(`You are here: <b>${airport.name}</b>`);
        marker.openPopup();
        marker.setIcon(greenIcon);
      } else {
        marker.setIcon(blueIcon);
        const popupContent = document.createElement('div');
        const h4 = document.createElement('h4');
        h4.innerHTML = airport.name;
        popupContent.append(h4);

        const flyButton = document.createElement('button');
        flyButton.classList.add('button');
        flyButton.innerHTML = `<span>Fly here</span>`;
        popupContent.append(flyButton);

        const p = document.createElement('p');
        p.innerHTML = `Distance: ${airport.distance} km`;
        popupContent.append(p);
        marker.bindPopup(popupContent);

        // http://127.0.0.1:8000/flyto?game=fEC7n0loeL95awIxgY7M&dest=EFHK&consumption=123
        flyButton.addEventListener('click', function () {
          gameSetup(`${apiURL}flyto?game=${gameData.status.id}&dest=${airport.ident}&consumption=${airport.co2_consumption}`);
        })
      }
    }
    updateGoals(gameData.goals);
  } catch (err) {
    console.log(err);
  }
}

// player form
document.querySelector('#player-form').addEventListener('submit', function (evt) {
  evt.preventDefault();
  // Get player name
  const playerName = document.querySelector('#player_name').value;

  // Get all the radio buttons in the form
  const radioButtons = document.querySelectorAll('input[type="radio"]');

  // Loop through the radio buttons and check which one is checked
  let selectedOption;
  radioButtons.forEach(function(radioButton) {
    if (radioButton.checked) {
      selectedOption = radioButton.value;
    }
  });

  document.querySelector('.settings').classList.remove('active');
  gameSetup(`${apiURL}newgame?player=${playerName}&loc=${selectedOption}`);
  document.querySelector('.top-box').classList.add('active');
  document.querySelector('.airport-box').classList.add('active');
  document.querySelector('.goals-box').classList.add('active');
  document.querySelector('.box').classList.add('active');
  document.querySelector('.profile').classList.add('hide');  
});

//----------- UI -----------

const allProgress = document.querySelectorAll('section .top-box .progress');
const profile = document.querySelector('section .top-box .profile');
const iconProfile = profile.querySelector('.iconProfile');
const dropdownProfile = profile.querySelector('.profile-link');

const iconGame = dropdownProfile.querySelector('a');
const settings = document.querySelector('.settings');
const iconSettings = settings.querySelector('.iconSettings');

allProgress.forEach(item=> {
    item.style.setProperty('--value', item.dataset.value)
})

iconProfile.addEventListener('click', function () {
  dropdownProfile.classList.toggle('show');
})

window.addEventListener('click', function (e) {
  if(e.target !== iconProfile) {
      if(e.target !== dropdownProfile) {
          if(dropdownProfile.classList.contains('show')) {
              dropdownProfile.classList.remove('show');
          }
      }
  }
})

iconGame.addEventListener('click', function () {
  if(settings.classList.contains('active')) {
    settings.classList.remove('active');
  } else {
    settings.classList.toggle('active');
  }
})

iconSettings.addEventListener('click', function () {
  if(settings.classList.contains('active')) {
    settings.classList.remove('active');
  } else {
    settings.classList.toggle('active');
  }
})